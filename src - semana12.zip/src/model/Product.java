package model;

public class Product {
    protected int code;
    protected String name;
    protected int quantity;
    protected double price;
    public  Product(int code, String name, int quantity, double price){
        this.code = code;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }
    public void setCode(int code){
        this.code = code;
    }
    public int getCode(){
        return code;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    public void setQuantity(int quantity){
        this.quantity = quantity;
    }
    public int getQuantity(){
        return quantity;
    }
    public void setPrice(double price){
        this.price = price;
    }
    public double getPrice(){
        return price;
    }
    public void PrintAllInformation(){
        System.out.println("Codigo: " + code + " Nombre: " + name + " Cantidad: " + quantity + " Precio: " + price);
    }
}