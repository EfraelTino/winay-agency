package view;

import controller.ProductController;
import model.Product;
import services.DataBaseConnector;

import java.sql.ResultSet;
import java.util.Scanner;

public class MainView {

    DataBaseConnector databaseConnector;
    ProductController productController;
    public void Run(){
        boolean executing = true;
        Scanner scanner = new Scanner(System.in);
        productController = new ProductController();
        while (executing == true){
            System.out.println("1. Conectar con base de datos");
            System.out.println("2. Ejecutar query");
            System.out.println("3. Mostrar resultados");
            System.out.println("4. Insertar valores");
            System.out.println("5. Actualizar valores");
            System.out.println("6. Eliminar valores");
            System.out.println("7. Buscar Productos por nombre");
            System.out.println("8. Buscar Productos por precio");
            System.out.println("9. Salir");
            System.out.print("Ingrese una opcion: ");
            int option = Integer.parseInt(scanner.nextLine());
            switch (option){
                case 1:
                    ConnectDatabase(scanner);
                    break;
                case 2:
                    ExecuteQuery(scanner);
                    break;
                case 3:
                    productController.PrintAllProductsInformation();
                    break;
                case 4:
                    InsertValues(scanner);
                    break;
                case 5:
                    UpdateValues(scanner);
                    break;
                case 6:
                    DeleteValues(scanner);
                    break;
                case 7:
                    SearchProductName(scanner);
                    break;
                case 8:
                    SearchProductPrice(scanner);
                    break;
                case 9:
                    executing = false;
                    break;
                default:
                    System.out.println("Opción inválida");
                    break;
            }
        }

    }
    private void ConnectDatabase(Scanner scanner){
        System.out.print("Ingresa el nombre de usuario de la base de datos: ");
        String userName = scanner.nextLine();
        System.out.print("Ingresa la contraseña de usuario de la base de datos: ");
        String password = scanner.nextLine();
        databaseConnector = new DataBaseConnector();
        databaseConnector.SetConnection(userName,password);
    }
    private void ExecuteQuery(Scanner scanner){
        System.out.print("Ingresa la query que quieres ejecutar: ");
        String query = scanner.nextLine();
        productController.AddProduct(databaseConnector.ExecuteQuery(query));
    }
    private void InsertValues(Scanner scanner){
        System.out.print("Ingresa el nombre del producto: ");
        String name = scanner.nextLine();
        System.out.print("Ingresa la cantidad del producto: ");
        int quantity = Integer.parseInt(scanner.nextLine());
        System.out.print("Ingresa el precio del producto: ");
        double price = Double.parseDouble(scanner.nextLine());
        String query = "INSERT INTO productos (name, quantity, price) VALUES (?, ?, ?);";
        databaseConnector.InsertValues(query, name,quantity, price);
        productController.AddProduct(0, name,quantity,price);
    }
    private void UpdateValues(Scanner scanner){
        System.out.print("Ingresa el código del producto: ");
        int code = Integer.parseInt(scanner.nextLine());
        if(productController.ProductExists(code) == false){
            System.out.println("El producto no existe");
            return;
        }
        System.out.print("Ingresa el nombre del producto: ");
        String name = scanner.nextLine();
        System.out.print("Ingresa el precio del producto: ");
        int quantity = Integer.parseInt(scanner.nextLine());
        System.out.print("Ingresa el precio del producto: ");
        double price = Double.parseDouble(scanner.nextLine());
        String query = "UPDATE productos SET code = ?, name = ?, quantity = ?, price = ? WHERE code = ?;";
        databaseConnector.UpdateValues(query,code,name,quantity,price);
        productController.UpdateValues(code,name,quantity,price);
    }
    public void DeleteValues(Scanner scanner){
        System.out.print("Ingresa el código del producto: ");
        int code = Integer.parseInt(scanner.nextLine());
        if(productController.ProductExists(code) == false){
            System.out.println("El producto no existe");
            return;
        }

        String query = "DELETE from productos WHERE code = ?";
        databaseConnector.DeleteValues(query,code);
        productController.DeleteValues(code);
    }
    private void SearchProductName(Scanner scanner) {
        System.out.print("Ingresa el nombre del producto a buscar: ");
        String namesearch = scanner.nextLine();
        String query = "SELECT * FROM productos WHERE name = ?";
        ResultSet resultSet = databaseConnector.SearchProductName(query, namesearch);
        try {
            if (resultSet.next()) {
                int code = resultSet.getInt("code");
                String name = resultSet.getString("name");
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                Product product = new Product(code, name, quantity, price);
                product.PrintAllInformation();
            } else {
                System.out.println("No se encontraron productos con ese nombre");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    private void SearchProductPrice(Scanner scanner) {
        System.out.print("Ingresa el precio del producto a buscar: ");
        double pricesearch = Double.parseDouble(scanner.nextLine());
        String query = "SELECT * FROM productos WHERE price = ?";
        ResultSet resultSet = databaseConnector.SearchProductPrice(query, pricesearch);
        try {
            if (resultSet.next()) {
                int code = resultSet.getInt("code");
                String name = resultSet.getString("name");
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                Product product = new Product(code, name, quantity, price);
                product.PrintAllInformation();
            } else {
                System.out.println("No se encontraron productos con ese precio");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}