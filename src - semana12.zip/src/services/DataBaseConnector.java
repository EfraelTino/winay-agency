package services;

import java.sql.*;

public class DataBaseConnector {
    private String url = "";
    private String username = "";
    private String password = "";
    private String database = "";
    Connection connection;
    public void SetConnection(String username, String password){
        this.url = "jdbc:mysql://localhost:3306/";
        this.database = "ventas";
        this.url = this.url + this.database;
        this.username = username;
        this.password = password;
        try {
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    public ResultSet ExecuteQuery(String query) {
        ResultSet resultSet = null;
        try {
            connection = DriverManager.getConnection(url,username,password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return resultSet;
    }
    public void InsertValues(String query, String name, int quantity, double price){
        try{
            connection = DriverManager.getConnection(url,username,password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,name);
            preparedStatement.setInt(2,quantity);
            preparedStatement.setDouble(3,price);
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    public void UpdateValues(String query, int code, String name, int quantity, double price){
        try{
            connection = DriverManager.getConnection(url,username,password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1,code);
            preparedStatement.setString(2,name);
            preparedStatement.setInt(3,quantity);
            preparedStatement.setDouble(4,price);
            preparedStatement.setInt(5,code);
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    public void DeleteValues(String query, int code){
        try{
            connection = DriverManager.getConnection(url,username,password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            // "DELETE from productos WHERE codigo = ?"
            preparedStatement.setInt(1,code);
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    public ResultSet SearchProductName(String query, String name){
        ResultSet resultSet = null;
        try {
            connection = DriverManager.getConnection(url,username,password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,name);
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return resultSet;
    }
    public ResultSet SearchProductPrice(String query, double price){
        ResultSet resultSet = null;
        try {
            connection = DriverManager.getConnection(url,username,password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setDouble(1,price);
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return resultSet;
    }
}