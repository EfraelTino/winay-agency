package controller;

import model.Product;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Locale;

public class ProductDAO implements  IProductDAO {
    private ArrayList<Product> arrayListProducts = new ArrayList<Product>();

    public void AddProduct(int code, String name, int quantity, double price) {
        Product product = new Product(code, name, quantity, price);
        arrayListProducts.add(product);
    }

    public void AddProduct(ResultSet resultSet) {
        try {
            while (resultSet.next()) {
                int code = resultSet.getInt("code");
                String name = resultSet.getString("name");
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                Product product = new Product(code, name, quantity, price);
                arrayListProducts.add(product);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void UpdateValues(int code, String name, int quantity, double price) {
        for (int i = 0; i < arrayListProducts.size(); ++i) {
            if (arrayListProducts.get(i).getCode() == code) {
                arrayListProducts.get(i).setCode(code);
                arrayListProducts.get(i).setName(name);
                arrayListProducts.get(i).setQuantity(quantity);
                arrayListProducts.get(i).setPrice(price);
                break;
            }
        }
    }

    public void DeleteProduct(int code) {
        for (int i = 0; i < arrayListProducts.size(); ++i) {
            if (arrayListProducts.get(i).getCode() == code) {
                arrayListProducts.remove(i);
                System.out.println("El producto fue eliminado");
                return;
            }
        }
    }

    public ArrayList<Product> GetArrayListProducts() {
        return arrayListProducts;
    }

    public void SearchProductName(String name) {
        for (int i = 0; i < arrayListProducts.size(); i++) {
            if (arrayListProducts.get(i).getName().equalsIgnoreCase(name)){
                arrayListProducts.get(i).PrintAllInformation();
                return;
            }
        }
    }

    public void SearchProductPrice(double price) {
        for (int i = 0; i < arrayListProducts.size(); i++) {
            if (arrayListProducts.get(i).getPrice() == price) {
                arrayListProducts.get(i).PrintAllInformation();
                return;
            }
        }
    }
}