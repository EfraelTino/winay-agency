package controller;

import java.sql.ResultSet;

public interface IProductDAO {
    public void AddProduct(int code, String name,int quantity, double price);
    public void AddProduct(ResultSet resultSet);
    public void UpdateValues(int code, String name,int quantity, double price);
    public void DeleteProduct(int code);
    public void SearchProductName(String name);
    public void SearchProductPrice(double price);
}