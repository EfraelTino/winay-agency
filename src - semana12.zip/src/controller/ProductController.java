package controller;

import java.sql.ResultSet;

public class ProductController {

    ProductDAO productDAO = new ProductDAO();
    public void AddProduct(int code, String name, int quantity, double price){
        productDAO.AddProduct(code,name,quantity,price);
    }

    public void AddProduct(ResultSet resultSet){
        productDAO.AddProduct(resultSet);
    }

    public void PrintAllProductsInformation(){
        for(int i = 0; i < productDAO.GetArrayListProducts().size();++i){
            productDAO.GetArrayListProducts().get(i).PrintAllInformation();
        }
    }
    public boolean ProductExists(int code){
        boolean exists = false;
        for(int i = 0; i < productDAO.GetArrayListProducts().size();++i){
            if(productDAO.GetArrayListProducts().get(i).getCode() == code){
                exists = true;
                break;
            }
        }
        return exists;
    }

    public void UpdateValues(int code, String name, int quantity, double price){
        productDAO.UpdateValues(code,name,quantity,price);
    }

    public void DeleteValues(int code){
        productDAO.DeleteProduct(code);
    }

    public void SearchProductName(String name){
        productDAO.SearchProductName(name);
    }
    public void SearchProductPrice(double price){
        productDAO.SearchProductPrice(price);
    }
}